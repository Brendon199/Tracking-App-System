import { ChingwenaSignature } from './chingwena.service';

export class SignatureValidator {
  /**
   * Validates code signature during runtime
   */
  static validateCodeSignature(code: string): boolean {
    if (!ChingwenaSignature.verifySignature(code)) {
      console.error('Invalid Chingwena signature detected!');
      return false;
    }
    return true;
  }

  /**
   * Signs new code with Chingwena signature
   */
  static signNewCode(code: string, author: string): string {
    return ChingwenaSignature.signCode(code, author);
  }
}