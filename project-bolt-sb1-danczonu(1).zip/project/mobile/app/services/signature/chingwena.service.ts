import { createHash, createHmac } from 'crypto';
import { encode, decode } from 'base64-arraybuffer';

/**
 * @author Chingwena
 * @copyright 2024
 * 
 * Chingwena Digital Signature Service
 * A unique code signing and verification system
 */
export class ChingwenaSignature {
  private static readonly SIGNATURE_HEADER = '/* CHINGWENA DIGITAL SIGNATURE */';
  private static readonly SIGNATURE_VERSION = '1.0.0';
  private static readonly SIGNATURE_ALGORITHM = 'sha512';
  
  // Unique Chingwena signature pattern
  private static readonly SIGNATURE_PATTERN = new Uint8Array([
    0x43, 0x48, 0x49, 0x4E, // "CHIN"
    0x47, 0x57, 0x45, 0x4E, // "GWEN"
    0x41, 0x2D, 0x53, 0x49, // "A-SI"
    0x47, 0x4E, 0x2D, 0x76  // "GN-v"
  ]);

  /**
   * Signs code with the Chingwena digital signature
   */
  static signCode(code: string, authorName: string = 'Chingwena'): string {
    const timestamp = new Date().toISOString();
    const codeHash = this.generateCodeHash(code);
    
    const signature = {
      author: authorName,
      timestamp,
      version: this.SIGNATURE_VERSION,
      hash: codeHash,
      verified: true
    };

    const signatureBlock = `${this.SIGNATURE_HEADER}
/**
 * ${JSON.stringify(signature, null, 2)}
 * 
 * This code is protected by Chingwena Digital Signature
 * Any unauthorized modification will invalidate this signature
 */\n\n`;

    return signatureBlock + code;
  }

  /**
   * Verifies the Chingwena signature on code
   */
  static verifySignature(signedCode: string): boolean {
    try {
      if (!signedCode.startsWith(this.SIGNATURE_HEADER)) {
        return false;
      }

      const signatureEnd = signedCode.indexOf('*/\n\n') + 4;
      const signatureBlock = signedCode.substring(0, signatureEnd);
      const code = signedCode.substring(signatureEnd);

      const signature = JSON.parse(
        signatureBlock.match(/\/\*\*\n \* ({[\s\S]+?})/)[1]
      );

      const currentHash = this.generateCodeHash(code);
      return currentHash === signature.hash;
    } catch (error) {
      console.error('Signature verification failed:', error);
      return false;
    }
  }

  /**
   * Generates a unique Chingwena hash for code verification
   */
  private static generateCodeHash(code: string): string {
    const hmac = createHmac(this.SIGNATURE_ALGORITHM, this.SIGNATURE_PATTERN);
    hmac.update(code);
    return hmac.digest('base64');
  }
}