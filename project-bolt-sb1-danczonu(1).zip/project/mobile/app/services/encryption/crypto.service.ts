import { Buffer } from 'buffer';
import { createHash, randomBytes, createCipheriv, createDecipheriv } from 'crypto';

export class CryptoService {
  private static readonly ALGORITHM = 'aes-256-gcm';
  private static readonly KEY_LENGTH = 32;
  private static readonly IV_LENGTH = 16;
  private static readonly SALT_LENGTH = 64;
  private static readonly TAG_LENGTH = 16;

  private static instance: CryptoService;
  private key: Buffer;

  private constructor() {
    // Generate unique device-specific key
    this.key = this.generateKey();
  }

  static getInstance(): CryptoService {
    if (!this.instance) {
      this.instance = new CryptoService();
    }
    return this.instance;
  }

  private generateKey(): Buffer {
    const deviceId = this.getDeviceFingerprint();
    const salt = randomBytes(this.SALT_LENGTH);
    return createHash('sha256')
      .update(Buffer.concat([Buffer.from(deviceId), salt]))
      .digest();
  }

  encrypt(data: string): string {
    const iv = randomBytes(this.IV_LENGTH);
    const cipher = createCipheriv(this.ALGORITHM, this.key, iv);
    
    const encrypted = Buffer.concat([
      cipher.update(data, 'utf8'),
      cipher.final()
    ]);

    const tag = cipher.getAuthTag();
    
    return Buffer.concat([iv, tag, encrypted]).toString('base64');
  }

  decrypt(data: string): string {
    const buffer = Buffer.from(data, 'base64');
    
    const iv = buffer.slice(0, this.IV_LENGTH);
    const tag = buffer.slice(this.IV_LENGTH, this.IV_LENGTH + this.TAG_LENGTH);
    const encrypted = buffer.slice(this.IV_LENGTH + this.TAG_LENGTH);
    
    const decipher = createDecipheriv(this.ALGORITHM, this.key, iv);
    decipher.setAuthTag(tag);
    
    return decipher.update(encrypted) + decipher.final('utf8');
  }

  private getDeviceFingerprint(): string {
    // Implement device-specific fingerprinting
    // This is a simplified version - implement more robust fingerprinting
    const { Device } = require('@nativescript/core');
    return createHash('sha256')
      .update(`${Device.uuid}-${Device.model}-${Device.manufacturer}`)
      .digest('hex');
  }
}