import { Geolocation } from '@nativescript/geolocation';
import { api } from '../utils/api';

export async function initializeGeolocation() {
    const hasPermission = await Geolocation.enableLocationRequest();
    if (hasPermission) {
        startLocationTracking();
    }
}

async function startLocationTracking() {
    try {
        const location = await Geolocation.getCurrentLocation({
            desiredAccuracy: 3,
            updateDistance: 10,
            maximumAge: 20000,
            timeout: 20000
        });

        // Send location to backend
        await api.post('/location/update', {
            latitude: location.latitude,
            longitude: location.longitude,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('Error tracking location:', error);
    }
}