import { Device } from '@nativescript/core';
import { api } from '../utils/api';

export async function registerDevice() {
    const deviceInfo = {
        uuid: Device.uuid,
        model: Device.model,
        manufacturer: Device.manufacturer,
        deviceType: Device.deviceType,
        // Note: IMEI access is restricted on modern devices
        // We use UUID as a device identifier instead
    };

    try {
        await api.post('/device/register', deviceInfo);
    } catch (error) {
        console.error('Error registering device:', error);
    }
}