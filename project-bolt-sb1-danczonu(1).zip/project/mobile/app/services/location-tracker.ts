import { Geolocation } from '@nativescript/geolocation';
import { api } from '../utils/api';
import { Device } from '@nativescript/core';
import { CryptoService } from './encryption/crypto.service';
import { AnomalyDetectorService } from './ai/anomaly-detector.service';
import { LocationData } from '../types/location.types';

export class LocationTracker {
  private static instance: LocationTracker;
  private tracking: boolean = false;
  private interval: number = 5 * 60 * 1000;
  private locationHistory: LocationData[] = [];
  private readonly HISTORY_SIZE = 50;

  private constructor() {}

  static getInstance(): LocationTracker {
    if (!this.instance) {
      this.instance = new LocationTracker();
    }
    return this.instance;
  }

  async startTracking(): Promise<void> {
    if (this.tracking) return;
    
    try {
      const hasPermission = await Geolocation.enableLocationRequest(true);
      if (!hasPermission) {
        throw new Error('Location permission denied');
      }

      this.tracking = true;
      this.trackLocation();
    } catch (error) {
      console.error('Failed to start tracking:', error);
      throw error;
    }
  }

  private async trackLocation(): Promise<void> {
    if (!this.tracking) return;

    try {
      const location = await Geolocation.getCurrentLocation({
        desiredAccuracy: 3,
        updateDistance: 10,
        maximumAge: 20000,
        timeout: 20000
      });

      const locationData: LocationData = {
        latitude: location.latitude,
        longitude: location.longitude,
        timestamp: new Date().getTime(),
        speed: location.speed || 0
      };

      this.updateLocationHistory(locationData);
      await this.analyzeAndSendLocation(locationData);
    } catch (error) {
      console.error('Error tracking location:', error);
    } finally {
      setTimeout(() => this.trackLocation(), this.interval);
    }
  }

  private updateLocationHistory(location: LocationData): void {
    this.locationHistory.push(location);
    if (this.locationHistory.length > this.HISTORY_SIZE) {
      this.locationHistory.shift();
    }
  }

  private async analyzeAndSendLocation(location: LocationData): Promise<void> {
    const crypto = CryptoService.getInstance();
    const anomalyDetector = AnomalyDetectorService.getInstance();

    try {
      // Detect potential theft based on movement patterns
      const isAnomalous = await anomalyDetector.detectAnomaly(this.locationHistory);

      if (isAnomalous) {
        this.interval = 60 * 1000; // Increase frequency to 1 minute
      }

      // Encrypt location data
      const encryptedData = crypto.encrypt(JSON.stringify({
        deviceId: Device.uuid,
        location,
        isAnomalous
      }));

      await api.post('/location/update', { data: encryptedData });
    } catch (error) {
      console.error('Failed to process and send location:', error);
    }
  }

  stopTracking(): void {
    this.tracking = false;
  }
}