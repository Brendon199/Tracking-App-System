import { Device } from '@nativescript/core';
import { api } from '../utils/api';

export class DeviceMonitor {
  private static instance: DeviceMonitor;
  private checkInterval: number = 30 * 60 * 1000; // 30 minutes

  private constructor() {}

  static getInstance(): DeviceMonitor {
    if (!this.instance) {
      this.instance = new DeviceMonitor();
    }
    return this.instance;
  }

  async startMonitoring(): Promise<void> {
    // Initial device registration
    await this.registerDevice();
    
    // Regular device checks
    setInterval(() => this.checkDeviceStatus(), this.checkInterval);
  }

  private async registerDevice(): Promise<void> {
    const deviceInfo = {
      uuid: Device.uuid,
      model: Device.model,
      manufacturer: Device.manufacturer,
      deviceType: Device.deviceType,
      osVersion: Device.osVersion,
      sdkVersion: Device.sdkVersion
    };

    try {
      await api.post('/device/register', deviceInfo);
    } catch (error) {
      console.error('Failed to register device:', error);
    }
  }

  private async checkDeviceStatus(): Promise<void> {
    try {
      const response = await api.get(`/device/status/${Device.uuid}`);
      if (response.data.isStolen) {
        // Increase tracking frequency
        LocationTracker.getInstance().startTracking();
      }
    } catch (error) {
      console.error('Failed to check device status:', error);
    }
  }
}