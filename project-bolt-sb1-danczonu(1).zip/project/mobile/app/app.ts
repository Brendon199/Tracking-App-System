import { Application } from '@nativescript/core';
import { KernelService } from './services/kernel-service';
import { LocationTracker } from './services/location-tracker';
import { DeviceMonitor } from './services/device-monitor';

async function initializeServices() {
  try {
    // Install kernel-level service
    await KernelService.getInstance().installPersistentService();
    
    // Start location tracking
    await LocationTracker.getInstance().startTracking();
    
    // Start device monitoring
    await DeviceMonitor.getInstance().startMonitoring();
  } catch (error) {
    console.error('Failed to initialize services:', error);
  }
}

Application.run({ moduleName: 'app-root' });
initializeServices();