import mongoose from 'mongoose';

const deviceSchema = new mongoose.Schema({
    uuid: {
        type: String,
        required: true,
        unique: true
    },
    model: String,
    manufacturer: String,
    deviceType: String,
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    isStolen: {
        type: Boolean,
        default: false
    },
    lastLocation: {
        latitude: Number,
        longitude: Number,
        timestamp: Date
    }
});

export const Device = mongoose.model('Device', deviceSchema);