import React, { useState } from 'react';
import { useDeviceTracking } from '../hooks/useDeviceTracking';
import { Button } from './ui/Button';

export const DeviceTracker: React.FC = () => {
  const [deviceId, setDeviceId] = useState('');
  const { location, isLoading, error, handleTrackDevice, handleReportStolen } = useDeviceTracking();

  return (
    <div className="max-w-md mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">Device Tracker</h2>
      <div className="space-y-4">
        <input
          type="text"
          value={deviceId}
          onChange={(e) => setDeviceId(e.target.value)}
          placeholder="Enter Device ID"
          className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        />
        <div className="space-x-2">
          <Button
            onClick={() => handleTrackDevice(deviceId)}
            isLoading={isLoading}
            variant="primary"
          >
            Track Device
          </Button>
          <Button
            onClick={() => handleReportStolen(deviceId)}
            isLoading={isLoading}
            variant="danger"
          >
            Report Stolen
          </Button>
        </div>
        {error && (
          <div className="text-red-500 mt-2">{error}</div>
        )}
        {location && (
          <div className="mt-4 p-4 bg-gray-100 rounded">
            <h3 className="font-bold">Last Known Location:</h3>
            <p>Latitude: {location.latitude}</p>
            <p>Longitude: {location.longitude}</p>
            <p>Last Updated: {new Date(location.timestamp).toLocaleString()}</p>
          </div>
        )}
      </div>
    </div>
  );
};