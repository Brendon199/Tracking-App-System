import React from 'react';
import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

export const PaymentForm: React.FC = () => {
  const handleSubscribe = async () => {
    const stripe = await stripePromise;
    if (!stripe) return;

    try {
      // Create checkout session through your backend
      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
      });
      const session = await response.json();

      // Redirect to Stripe Checkout
      await stripe.redirectToCheckout({
        sessionId: session.id,
      });
    } catch (error) {
      console.error('Payment error:', error);
    }
  };

  return (
    <div className="max-w-md mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">Subscribe to Track Pro</h2>
      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="mb-4">
          <h3 className="text-xl font-semibold">Premium Features</h3>
          <ul className="list-disc ml-6 mt-2">
            <li>Real-time device tracking</li>
            <li>Instant stolen device alerts</li>
            <li>Remote device control</li>
            <li>24/7 support</li>
          </ul>
        </div>
        <button
          onClick={handleSubscribe}
          className="w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600"
        >
          Subscribe Now
        </button>
      </div>
    </div>
  );
};