import { useState } from 'react';
import { DeviceLocation, DeviceTrackingResponse } from '../types/device';
import { trackDevice, reportStolen } from '../services/api';
import { useToast } from '../hooks/useToast';

export const useDeviceTracking = () => {
  const [location, setLocation] = useState<DeviceLocation | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { showToast } = useToast();

  const handleTrackDevice = async (deviceId: string) => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await trackDevice(deviceId);
      setLocation(response.location);
      showToast('Device location updated successfully', 'success');
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to track device';
      setError(errorMessage);
      showToast(errorMessage, 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReportStolen = async (deviceId: string) => {
    try {
      setIsLoading(true);
      setError(null);
      await reportStolen(deviceId);
      showToast('Device reported as stolen', 'success');
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to report device';
      setError(errorMessage);
      showToast(errorMessage, 'error');
    } finally {
      setIsLoading(false);
    }
  };

  return {
    location,
    isLoading,
    error,
    handleTrackDevice,
    handleReportStolen,
  };
};