import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3000/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

export const trackDevice = async (deviceId: string) => {
  const response = await api.get(`/devices/${deviceId}/location`);
  return response.data;
};

export const reportStolen = async (deviceId: string) => {
  const response = await api.post(`/devices/${deviceId}/report-stolen`);
  return response.data;
};

export default api;