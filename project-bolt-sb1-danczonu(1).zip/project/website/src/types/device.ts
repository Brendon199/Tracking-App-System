export interface DeviceLocation {
  latitude: number;
  longitude: number;
  timestamp: string;
}

export interface Device {
  id: string;
  uuid: string;
  model: string;
  manufacturer: string;
  deviceType: string;
  isStolen: boolean;
  lastLocation?: DeviceLocation;
}

export interface DeviceTrackingResponse {
  success: boolean;
  device: Device;
  location: DeviceLocation;
}